import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { AcessoriosService } from './acessorio.service';
import { CreateAcessorioDto } from './dto/create-acessorio.dto';
import { UpdateAcessorioDto } from './dto/update-acessorio.dto';

@Controller('acessorios')
export class AcessoriosController {
  constructor(private readonly acessoriosService: AcessoriosService) {}

  @Post()
  create(@Body() dto: CreateAcessorioDto) {
    return this.acessoriosService.create(dto);
  }

  @Get()
  findAll() {
    return this.acessoriosService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.acessoriosService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateAcessorioDto) {
    return this.acessoriosService.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.acessoriosService.remove(id);
  }
}
