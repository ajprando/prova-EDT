import { Test, TestingModule } from '@nestjs/testing';
import { AcessoriosService } from './acessorio.service';

describe('AcessorioService', () => {
  let service: AcessoriosService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AcessoriosService],
    }).compile();

    service = module.get<AcessoriosService>(AcessoriosService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
