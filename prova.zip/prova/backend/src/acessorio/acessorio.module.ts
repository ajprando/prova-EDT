import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AcessoriosService } from './acessorio.service';
import { AcessoriosController } from './acessorio.controller';
import { Acessorio, AcessorioSchema } from './schemas/acessorio.schema';

@Module({
  imports: [MongooseModule.forFeature([{ name: Acessorio.name, schema: AcessorioSchema }])],
  controllers: [AcessoriosController],
  providers: [AcessoriosService],
  exports: [AcessoriosService],
})
export class AcessoriosModule {}
