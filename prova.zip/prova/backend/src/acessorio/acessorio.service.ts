import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Acessorio } from './schemas/acessorio.schema';
import { CreateAcessorioDto } from './dto/create-acessorio.dto';
import { UpdateAcessorioDto } from './dto/update-acessorio.dto';

@Injectable()
export class AcessoriosService {
  constructor(@InjectModel(Acessorio.name) private acessorioModel: Model<Acessorio>) {}

  create(dto: CreateAcessorioDto) {
    return this.acessorioModel.create(dto);
  }

  findAll() {
    return this.acessorioModel.find().exec();
  }

  async findOne(id: string) {
    const a = await this.acessorioModel.findById(id).exec();
    if (!a) throw new NotFoundException('O Acessório não foi encontrado.');
    return a;
  }

  update(id: string, dto: UpdateAcessorioDto) {
    return this.acessorioModel.findByIdAndUpdate(id, dto, { new: true }).exec();
  }

  remove(id: string) {
    return this.acessorioModel.findByIdAndDelete(id).exec();
  }
}
