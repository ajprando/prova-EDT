import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema()
export class Acessorio extends Document {
    @Prop({ required: true })
    nome: string;
}

export const AcessorioSchema = SchemaFactory.createForClass(Acessorio);