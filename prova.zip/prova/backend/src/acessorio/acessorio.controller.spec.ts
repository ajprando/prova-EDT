import { Test, TestingModule } from '@nestjs/testing';
import { AcessoriosController } from './acessorio.controller';
import { AcessoriosService } from './acessorio.service';

describe('AcessorioController', () => {
  let controller: AcessoriosController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AcessoriosController],
      providers: [AcessoriosService],
    }).compile();

    controller = module.get<AcessoriosController>(AcessoriosController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
