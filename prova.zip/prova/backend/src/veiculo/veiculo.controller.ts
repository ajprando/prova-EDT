import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { VeiculosService } from './veiculo.service';
import { CreateVeiculoDto } from './dto/create-veiculo.dto';
import { UpdateVeiculoDto } from './dto/update-veiculo.dto';

@Controller('veiculos')
export class VeiculosController {
  constructor(private readonly veiculosService: VeiculosService) {}

  @Post()
  create(@Body() dto: CreateVeiculoDto) {
    return this.veiculosService.create(dto);
  }

  @Get()
  findAll() {
    return this.veiculosService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.veiculosService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateVeiculoDto) {
    return this.veiculosService.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.veiculosService.remove(id);
  }

  @Post(':id/addAcessorio/:acessorioId')
  addAcessorio(@Param('id') id: string, @Param('acessorioId') acessorioId: string) {
    return this.veiculosService.addAcessorio(id, acessorioId);
  }

  @Delete(':id/removeAcessorio/:acessorioId')
  removeAcessorio(@Param('id') id: string, @Param('acessorioId') acessorioId: string) {
    return this.veiculosService.removeAcessorio(id, acessorioId);
  }
}
