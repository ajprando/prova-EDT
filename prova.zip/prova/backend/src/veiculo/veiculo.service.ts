import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Veiculo } from './schemas/veiculo.schema';
import { Acessorio } from '../acessorio/schemas/acessorio.schema';
import { CreateVeiculoDto } from './dto/create-veiculo.dto';
import { UpdateVeiculoDto } from './dto/update-veiculo.dto';

@Injectable()
export class VeiculosService {
  constructor(
    @InjectModel(Veiculo.name) private veiculoModel: Model<Veiculo>,
    @InjectModel(Acessorio.name) private acessorioModel: Model<Acessorio>,
  ) {}

  async create(dto: CreateVeiculoDto) {
    const acessoriosObjIds = dto.acessorios?.map(id => new Types.ObjectId(id)) || [];
    return this.veiculoModel.create({ ...dto, acessorios: acessoriosObjIds });
  }

  findAll() {
    return this.veiculoModel.find().populate('acessorios').exec();
  }

  async findOne(id: string) {
    const v = await this.veiculoModel.findById(id).populate('acessorios').exec();
    if (!v) throw new NotFoundException('O Veículo não foi encontrado.');
    return v;
  }

  async update(id: string, dto: UpdateVeiculoDto) {
    const data: any = { ...dto };
    if (dto.acessorios) data.acessorios = dto.acessorios.map(id => new Types.ObjectId(id));
    const updated = await this.veiculoModel.findByIdAndUpdate(id, data, { new: true }).populate('acessorios').exec();
    if (!updated) throw new NotFoundException('O Veículo não foi encontrado.');
    return updated;
  }

  async remove(id: string) {
    const removed = await this.veiculoModel.findByIdAndDelete(id).exec();
    if (!removed) throw new NotFoundException('O Veículo não foi encontrado.');
    return removed;
  }

  async addAcessorio(veiculoId: string, acessorioId: string) {
    const act = await this.acessorioModel.findById(acessorioId).exec();
    if (!act) throw new NotFoundException('O Acessório não foi encontrado.');

    const updated = await this.veiculoModel
      .findByIdAndUpdate(
        veiculoId,
        { $addToSet: { acessorios: new Types.ObjectId(acessorioId) } },
        { new: true },
      )
      .populate('acessorios')
      .exec();

    if (!updated) throw new NotFoundException('O Veículo não foi encontrado.');
    return updated;
  }

  async removeAcessorio(veiculoId: string, acessorioId: string) {
    const updated = await this.veiculoModel
      .findByIdAndUpdate(
        veiculoId,
        { $pull: { acessorios: new Types.ObjectId(acessorioId) } },
        { new: true },
      )
      .populate('acessorios')
      .exec();

    if (!updated) throw new NotFoundException('O Veículo não foi encontrado.');
    return updated;
  }
}
