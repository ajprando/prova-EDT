import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { VeiculosService } from './veiculo.service';
import { VeiculosController } from './veiculo.controller';
import { Veiculo, VeiculoSchema } from './schemas/veiculo.schema';
import { Acessorio, AcessorioSchema } from '../acessorio/schemas/acessorio.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Veiculo.name, schema: VeiculoSchema }]),
    MongooseModule.forFeature([{ name: Acessorio.name, schema: AcessorioSchema }]),
  ],
  controllers: [VeiculosController],
  providers: [VeiculosService],
})
export class VeiculosModule {}
