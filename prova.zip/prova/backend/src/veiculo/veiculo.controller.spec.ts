import { Test, TestingModule } from '@nestjs/testing';
import { VeiculosController } from './veiculo.controller';
import { VeiculosService } from './veiculo.service';

describe('VeiculoController', () => {
  let controller: VeiculosController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [VeiculosController],
      providers: [VeiculosService],
    }).compile();

    controller = module.get<VeiculosController>(VeiculosController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
