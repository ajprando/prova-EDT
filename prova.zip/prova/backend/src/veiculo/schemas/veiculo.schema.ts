import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Acessorio } from '../../acessorio/schemas/acessorio.schema';

@Schema()
export class Veiculo extends Document {
  @Prop({ required: true })
  modelo: string;

  @Prop({ required: true })
  anoFabricacao: number;

  @Prop({ required: true })
  placa: string;

  @Prop({ type: [{ type: Types.ObjectId, ref: Acessorio.name }] })
  acessorios: Types.ObjectId[];
}

export const VeiculoSchema = SchemaFactory.createForClass(Veiculo);
