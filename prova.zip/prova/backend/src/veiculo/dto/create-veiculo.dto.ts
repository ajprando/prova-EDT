import { IsString, IsInt, IsOptional, IsArray, IsMongoId } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateVeiculoDto {
  @IsString()
  modelo: string;

  @Type(() => Number)
  @IsInt()
  anoFabricacao: number;

  @IsString()
  placa: string;

  @IsOptional()
  @IsArray()
  @IsMongoId({ each: true })
  acessorios?: string[];
}
