import { useState } from 'react';
import VeiculosPage from './pages/VeiculosPage';
import AcessoriosPage from './pages/AcessoriosPage';

export default function App() {
  const [page, setPage] = useState<'veiculos' | 'acessorios'>('veiculos');

  return (
    <div>
      <header style={{ marginBottom: 12 }}>
        <h1>CRUD — Veículos & Acessórios</h1>
        <nav>
          <button onClick={() => setPage('veiculos')}>Veículos</button>
          <button onClick={() => setPage('acessorios')}>Acessórios</button>
        </nav>
      </header>

      {page === 'veiculos' ? <VeiculosPage /> : <AcessoriosPage />}
    </div>
  );
}
