import React, { useEffect, useState } from 'react';
import { api } from '../api';
import type { Veiculo, Acessorio } from '../types';

export default function VeiculosPage() {
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [acessorios, setAcessorios] = useState<Acessorio[]>([]);
  const [modelo, setModelo] = useState('');
  const [anoFabricacao, setAnoFabricacao] = useState('');
  const [placa, setPlaca] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedAcessorio, setSelectedAcessorio] = useState<string>('');

  async function fetchAll() {
    setLoading(true);
    try {
      const [resVeiculos, resAcessorios] = await Promise.all([
        api.get<Veiculo[]>('/veiculos'),
        api.get<Acessorio[]>('/acessorios'),
      ]);
      setVeiculos(resVeiculos.data);
      setAcessorios(resAcessorios.data);
    } catch (err) {
      console.error(err);
      alert('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchAll(); }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!modelo.trim() || !anoFabricacao.trim() || !placa.trim()) return;
    try {
      await api.post('/veiculos', { modelo, anoFabricacao: Number(anoFabricacao), placa });
      setModelo(''); setAnoFabricacao(''); setPlaca('');
      fetchAll();
    } catch (err) {
      console.error(err);
      alert('Erro ao criar veículo');
    }
  }

  async function handleDelete(id?: string) {
    if (!id) return;
    if (!confirm('Excluir veículo?')) return;
    try {
      await api.delete(`/veiculos/${id}`);
      setVeiculos(prev => prev.filter(v => v._id !== id));
    } catch (err) {
      console.error(err);
      alert('Erro ao excluir veículo');
    }
  }

  async function handleAddAcessorio(veiculoId: string) {
    if (!selectedAcessorio) return alert('Selecione um acessório');
    try {
      await api.post(`/veiculos/${veiculoId}/addAcessorio/${selectedAcessorio}`);
      setSelectedAcessorio('');
      fetchAll();
    } catch (err) {
      console.error(err);
      alert('Erro ao adicionar acessório');
    }
  }

  async function handleRemoveAcessorio(veiculoId: string, acessorioId: string) {
    try {
      await api.delete(`/veiculos/${veiculoId}/removeAcessorio/${acessorioId}`);
      fetchAll();
    } catch (err) {
      console.error(err);
      alert('Erro ao remover acessório');
    }
  }

  function acessoriosNomes(list?: (Acessorio | string)[]) {
    if (!list || list.length === 0) return 'Nenhum';
    return list.map(a => typeof a === 'string' ? a : a.nome).join(', ');
  }

  return (
    <div>
      <h2>Veículos</h2>

      <form onSubmit={handleCreate} style={{ marginBottom: 12 }}>
        <input placeholder="Modelo" value={modelo} onChange={e => setModelo(e.target.value)} />
        <input placeholder="Ano Fabricação" type="number" value={anoFabricacao} onChange={e => setAnoFabricacao(e.target.value)} />
        <input placeholder="Placa" value={placa} onChange={e => setPlaca(e.target.value)} />
        <button type="submit">Criar veículo</button>
      </form>

      {loading ? <p>Carregando...</p> : (
        <ul>
          {veiculos.length === 0 && <li>Nenhum veículo</li>}
          {veiculos.map(v => (
            <li key={v._id}>
              <strong>{v.modelo}</strong> ({v.anoFabricacao}) — Placa: {v.placa}
              <br />
              Acessórios: {acessoriosNomes(v.acessorios)}
              <br />

              <select value={selectedAcessorio} onChange={e => setSelectedAcessorio(e.target.value)}>
                <option value="">Selecione acessório</option>
                {acessorios.map(a => <option key={a._id} value={a._id}>{a.nome}</option>)}
              </select>
              <button onClick={() => handleAddAcessorio(v._id!)}>Adicionar</button>

              <ul>
                {(v.acessorios || []).map(a => {
                  const ac = typeof a === 'string' ? { _id: a, nome: a } : a;
                  return (
                    <li key={ac._id}>
                      {ac.nome}
                      <button onClick={() => handleRemoveAcessorio(v._id!, ac._id!)}>Remover</button>
                    </li>
                  );
                })}
              </ul>

              <button onClick={() => handleDelete(v._id)}>Excluir Veículo</button>
              <hr />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
