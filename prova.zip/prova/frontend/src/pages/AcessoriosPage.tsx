import React, { useEffect, useState } from 'react';
import { api } from '../api';
import type { Acessorio } from '../types';

export default function AcessoriosPage() {
  const [acessorios, setAcessorios] = useState<Acessorio[]>([]);
  const [nome, setNome] = useState('');
  const [loading, setLoading] = useState(false);

  async function fetchAcessorios() {
    setLoading(true);
    try {
      const res = await api.get<Acessorio[]>('/acessorios');
      setAcessorios(res.data);
    } catch (err) {
      console.error(err);
      alert('Erro ao buscar acessórios');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchAcessorios(); }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!nome.trim()) return;
    try {
      await api.post('/acessorios', { nome });
      setNome('');
      fetchAcessorios();
    } catch (err) {
      console.error(err);
      alert('Erro ao criar acessório');
    }
  }

  async function handleDelete(id?: string) {
    if (!id) return;
    if (!confirm('Excluir acessório?')) return;
    try {
      await api.delete(`/acessorios/${id}`);
      setAcessorios(prev => prev.filter(a => a._id !== id));
    } catch (err) {
      console.error(err);
      alert('Erro ao excluir acessório');
    }
  }

  return (
    <div>
      <h2>Acessórios</h2>

      <form onSubmit={handleCreate} style={{ marginBottom: 12 }}>
        <input placeholder="Nome" value={nome} onChange={e => setNome(e.target.value)} />
        <button type="submit">Criar</button>
      </form>

      {loading ? <p>Carregando...</p> : (
        <ul>
          {acessorios.length === 0 && <li>Nenhum acessório</li>}
          {acessorios.map(a => (
            <li key={a._id}>
              {a.nome}
              <button onClick={() => handleDelete(a._id)}>Excluir</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
