export interface Acessorio {
  _id?: string;
  nome: string;
}

export interface Veiculo {
  _id?: string;
  modelo: string;
  anoFabricacao: number;
  placa: string;
  acessorios?: (Acessorio | string)[];
}
